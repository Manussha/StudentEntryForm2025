import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class EntryForm {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Student Entry Form");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(new BorderLayout());

        // MenuBar
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenu helpMenu = new JMenu("Help");
        menuBar.add(fileMenu);
        menuBar.add(helpMenu);
        frame.setJMenuBar(menuBar);

        // Tabs
        JTabbedPane tabbedPane = new JTabbedPane();

        // Panel
        JPanel panel = new JPanel(new GridLayout(0, 2, 10, 10));

        JTextField nameField = new JTextField(15);
        JTextField dobField = new JTextField(15);
        JTextField nationalityField = new JTextField(15);
        JTextField langField = new JTextField(15);
        JTextField bgField = new JTextField(5);
        JTextField rField = new JTextField(15);
        JTextField aadhaarField = new JTextField(15);
        JTextField addressField = new JTextField(20);
        JTextField stateField = new JTextField(15);
        JTextField noField = new JTextField(11);
        JTextField mailField = new JTextField(20);

        panel.add(new JLabel("Full Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Date of Birth:"));
        panel.add(dobField);

        panel.add(new JLabel("Gender:"));
        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JRadioButton male = new JRadioButton("Male");
        JRadioButton female = new JRadioButton("Female");
        ButtonGroup bg= new ButtonGroup();
        bg.add(male);
        bg.add(female);
        genderPanel.add(male);
        genderPanel.add(female);
        panel.add(genderPanel);

        panel.add(new JLabel("Nationality:"));
        panel.add(nationalityField);
        panel.add(new JLabel("Mother Tongue:"));

        panel.add(langField);
        panel.add(new JLabel("Blood Group:"));

        panel.add(bgField);
        panel.add(new JLabel("Religion/Community:"));
        panel.add(rField);

        panel.add(new JLabel("Caste:"));
        JPanel castePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JRadioButton general = new JRadioButton("General");
        JRadioButton obc = new JRadioButton("OBC");
        JRadioButton bc = new JRadioButton("BC");
        JRadioButton mbc = new JRadioButton("MBC");
        JRadioButton sc = new JRadioButton("SC");
        JRadioButton st = new JRadioButton("ST");
        ButtonGroup cg = new ButtonGroup();
        cg.add(general);
        cg.add(obc);
        cg.add(bc);
        cg.add(mbc);
        cg.add(sc);
        cg.add(st);
        castePanel.add(general); castePanel.add(obc); castePanel.add(bc);
        castePanel.add(mbc); castePanel.add(sc); castePanel.add(st);
        panel.add(castePanel);

        panel.add(new JLabel("Aadhaar Number:"));
        panel.add(aadhaarField);
        panel.add(new JLabel("Residential Address:"));
        panel.add(addressField);
        panel.add(new JLabel("State:"));
        panel.add(stateField);
        panel.add(new JLabel("Contact Number:"));
        panel.add(noField);
        panel.add(new JLabel("Email Address:"));
        panel.add(mailField);

        JButton submitButton = new JButton("Submit");
        panel.add(new JLabel()); // empty label for spacing
        panel.add(submitButton);

        tabbedPane.add("Form", panel);

        // === TABLE PANEL ===
        String[] columns = {"Name", "DOB", "Gender", "Nationality", "Mother Tongue", "Blood Group",
                "Religion", "Caste", "Aadhaar", "Address", "State", "Contact", "Email"};

        DefaultTableModel tableModel = new DefaultTableModel(columns, 0);
        JTable table = new JTable(tableModel);
        JScrollPane tableScrollPane = new JScrollPane(table);

        tabbedPane.add("Student Data", tableScrollPane);

        frame.add(tabbedPane, BorderLayout.CENTER);

        // Action Listener
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String gender = male.isSelected() ? "Male" : (female.isSelected() ? "Female" : "");
                String caste = general.isSelected() ? "General" :
                        obc.isSelected() ? "OBC" :
                                bc.isSelected() ? "BC" :
                                        mbc.isSelected() ? "MBC" :
                                                sc.isSelected() ? "SC" :
                                                        st.isSelected() ? "ST" : "";

                String[] data = {
                        nameField.getText(),
                        dobField.getText(),
                        gender,
                        nationalityField.getText(),
                        langField.getText(),
                        bgField.getText(),
                        rField.getText(),
                        caste,
                        aadhaarField.getText(),
                        addressField.getText(),
                        stateField.getText(),
                        noField.getText(),
                        mailField.getText()
                };
                tableModel.addRow(data);
                tabbedPane.setSelectedIndex(1); // switch to table tab
            }
        });

        frame.setVisible(true);
    }
}